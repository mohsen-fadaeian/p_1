<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class MainLevel extends Model
{
    protected $fillable =[
        'name',
        'order_lvl'
    ];
}
